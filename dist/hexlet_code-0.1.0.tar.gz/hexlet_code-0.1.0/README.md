### Hexlet tests and linter status:
[![Actions Status](https://github.com/ArtourBatiskaf/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/ArtourBatiskaf/python-project-49/actions)
<a href="https://codeclimate.com/github/ArtourBatiskaf/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/3552ce47e1aff5d77927/maintainability" /></a>
[![asciicast](https://asciinema.org/a/0J81x8DG7uc1FVrSg3wbAK3Z9.svg)](https://asciinema.org/a/0J81x8DG7uc1FVrSg3wbAK3Z9)
[![asciicast](https://asciinema.org/a/Tv4szv6BsXphBnj4ujY0miI8G.svg)](https://asciinema.org/a/Tv4szv6BsXphBnj4ujY0miI8G)
[![asciicast](https://asciinema.org/a/p0EdRgfFVmLQvCrdvH35bYZjY.svg)](https://asciinema.org/a/p0EdRgfFVmLQvCrdvH35bYZjY)
[![asciicast](https://asciinema.org/a/Uja7JCPK2r9W2NS4yIdHvkTnt.svg)](https://asciinema.org/a/Uja7JCPK2r9W2NS4yIdHvkTnt)
[![asciicast](https://asciinema.org/a/DQ3ikC3INMAENFtx4yY1rkgK0.svg)](https://asciinema.org/a/DQ3ikC3INMAENFtx4yY1rkgK0)
