### Hexlet tests and linter status:
[![Actions Status](https://github.com/ArtourBatiskaf/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/ArtourBatiskaf/python-project-49/actions)
[![Maintainability](<a href="https://codeclimate.com/github/ArtourBatiskaf/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/3552ce47e1aff5d77927/maintainability" /></a>)
[![asciicast](https://asciinema.org/a/SOiVJrFxmJn435KufIrtX0lpv.svg)](https://asciinema.org/a/SOiVJrFxmJn435KufIrtX0lpv)
